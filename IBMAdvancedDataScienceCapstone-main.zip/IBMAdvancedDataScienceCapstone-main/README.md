# IBMAdvancedDataScienceCapstone
IBM Advanced DataScience Capstone Project

**Presentation youtube**: https://youtu.be/ursvLV3n7Mk
